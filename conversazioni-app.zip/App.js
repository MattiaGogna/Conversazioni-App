import React from "react";

function App() {
  return (
    <div style={{ padding: 20 }}>
      <h1>Conversazioni Fa.Im Impianti Srl</h1>
      <p>Benvenuto! Qui puoi gestire gruppi e caricare foto.</p>
    </div>
  );
}

export default App;
